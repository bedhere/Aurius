import datetime, hashlib, json, os, pathlib, shutil, sqlite3, subprocess, sys, urllib.request

workspace=pathlib.Path(__file__).resolve().parent
root=pathlib.Path('/opt/aurius')
site=pathlib.Path('/opt/1panel/www/sites/aurius.com.au/index')
database=root/'shared/db/aurius.db'
assets=['cyber-registered-design-202616120.png','rayclean-au3303-brd-hd-20261114.webp']
sources=json.loads((workspace/'expected.json').read_text())
photo='/products/'+assets[1]

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def backend():
    return {'environment':digest(root/'backend/.env'),'started_at':subprocess.check_output(['docker','inspect','-f','{{.State.StartedAt}}','aurius-build'],text=True).strip()}
def frontend():
    files=list((root/'frontend/src').rglob('*'))+list((root/'frontend/public').rglob('*'))+[root/'frontend'/name for name in ['package.json','vite.config.ts','tsconfig.json','index.html']]
    return {str(path.relative_to(root/'frontend')):digest(path) for path in files if path.is_file()}
def request(path):
    with urllib.request.urlopen('https://aurius.com.au'+path,timeout=30) as response:return response.read()
def catalogue():
    result=json.loads(request('/api/products?pageSize=50'));assert result['success']
    return result['data']
def atomic(source,target):
    target.parent.mkdir(parents=True,exist_ok=True)
    temporary=target.with_name(target.name+'.cyber-new')
    shutil.copy2(source,temporary);temporary.chmod(0o644);os.replace(temporary,target)
def save(state):
    for destination in [workspace/'state.json',pathlib.Path(state['backup'])/'deployment.json']:
        destination.write_text(json.dumps(state,indent=2));destination.chmod(0o600)

def verify(state):
    stage=pathlib.Path(state['stage'])
    assert hashlib.sha256(request('/products')).hexdigest()==digest(stage/'frontend/dist/index.html')
    for name in assets:
        assert hashlib.sha256(request('/products/'+name)).hexdigest()==digest(stage/'frontend/public/products'/name)
    # Check the actual JS chunks used by this build are live, including lazy page chunks.
    for pattern in ['Products-*.js','ProductDetail-*.js','product-label-*.js']:
        for path in (stage/'frontend/dist/assets').glob(pattern):
            assert hashlib.sha256(request('/assets/'+path.name)).hexdigest()==digest(path)
    data=catalogue()
    before={p['sku']:p for p in state['catalogue_before']['items']}
    after={p['sku']:p for p in data['items']}
    assert data['total']==state['catalogue_before']['total']
    for sku,original in before.items():
        expected=dict(original)
        if sku=='AU-3303-BRD':expected['images']=state['images_after']
        assert after[sku]==expected, 'Unintended catalogue change: '+sku
    detail=json.loads(request('/api/products/2'))['data']
    assert detail['images']==state['images_after'] and detail['images'][0]==photo
    assert backend()==state['backend_before']
    state['verified']={'live_entry_and_assets':True,'catalogue_and_price_preservation':True,'hd_primary_image_in_list_and_detail':True,'backend_kept_running':True}
    save(state)
    return state['verified']

mode=sys.argv[1]
if mode=='prepare':
    assert not (workspace/'state.json').exists(), 'Reuse existing preparation'
    for name,expected in sources.items():
        path=root/'frontend'/name
        assert (digest(path) if path.exists() else None)==expected, 'Source changed: '+name
    stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-cyber-design'
    stage=pathlib.Path('/opt/aurius-release-'+stamp)
    backup=pathlib.Path('/opt/aurius-backups')/stamp
    stage.mkdir(mode=0o700);backup.mkdir(mode=0o700)
    state={'stage':str(stage),'backup':str(backup),'frontend_before':frontend(),'backend_before':backend(),'index_before':digest(site/'index.html'),'catalogue_before':catalogue(),'sources':sources,'assets':assets}
    with sqlite3.connect('file:'+str(database)+'?mode=ro',uri=True) as connection:
        connection.row_factory=sqlite3.Row
        row=dict(connection.execute('SELECT * FROM Product WHERE sku=?',('AU-3303-BRD',)).fetchone())
        assert row['id']==2
        state['product_before']=row
        images=json.loads(row['images']);assert images and isinstance(images,list)
        state['images_after']=[photo,*images[1:]]
    shutil.copy2(site/'index.html',backup/'index.html')
    shutil.copytree(root/'frontend',stage/'frontend',ignore=shutil.ignore_patterns('node_modules','dist','*.tsbuildinfo'))
    shutil.copy2(root/'package.json',stage/'package.json')
    (stage/'node_modules').symlink_to(root/'node_modules',target_is_directory=True)
    for name in sources:
        original=root/'frontend'/name
        if original.exists():
            target=backup/'source'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(original,target)
        target=stage/'frontend'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(workspace/'source'/name,target)
    for name in assets:
        assert not (site/'products'/name).exists()
        shutil.copy2(workspace/'assets'/name,stage/'frontend/public/products'/name)
    save(state)
    subprocess.run(['npm','run','build','--prefix','frontend'],cwd=stage,check=True)
    bundle=''.join(path.read_text() for path in (stage/'frontend/dist/assets').glob('*.js'))
    assert assets[0] in bundle and all(sku in bundle for sku in ['AU-9585-BN','AU-9585-BRD'])
    state['prepared']=True;save(state)
    print(json.dumps({'prepared':True,'stage':str(stage),'backup':str(backup)},indent=2),flush=True)
elif mode=='deploy':
    state=json.loads((workspace/'state.json').read_text())
    assert state.get('prepared') and not state.get('deployed')
    assert frontend()==state['frontend_before'] and backend()==state['backend_before']
    assert digest(site/'index.html')==state['index_before']
    assert catalogue()==state['catalogue_before'], 'Catalogue changed after preparation'
    stage=pathlib.Path(state['stage']);backup=pathlib.Path(state['backup'])
    with sqlite3.connect('file:'+str(database)+'?mode=ro',uri=True) as connection:
        with sqlite3.connect(backup/'aurius-before.db') as destination:
            connection.backup(destination);assert destination.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
    (backup/'aurius-before.db').chmod(0o600)
    photo_updated=False;published=False;copied=[]
    try:
        shutil.copytree(stage/'frontend/dist/assets',site/'assets',dirs_exist_ok=True)
        for name in assets:
            for destination in [site/'products'/name,root/'frontend/public/products'/name]:atomic(stage/'frontend/public/products'/name,destination)
        now=int(datetime.datetime.now(datetime.timezone.utc).timestamp()*1000)
        after=json.dumps(state['images_after'])
        with sqlite3.connect(database,timeout=15) as connection:
            result=connection.execute('UPDATE Product SET images=?,updatedAt=? WHERE id=2 AND sku=? AND images=? AND updatedAt=?',(after,now,'AU-3303-BRD',state['product_before']['images'],state['product_before']['updatedAt']))
            assert result.rowcount==1, 'Product changed after preparation'
            connection.execute('INSERT INTO AuditLog(action,targetType,targetId,details,createdAt) VALUES(?,?,?,?,?)',('SETTINGS_CHANGED','Product','2',json.dumps({'imageUpdate':photo,'reason':'Customer requested a larger high-resolution gold RAYCLEAN image'}),now))
        photo_updated=True
        for name in sources:
            atomic(stage/'frontend'/name,root/'frontend'/name);copied.append(name)
        atomic(stage/'frontend/dist/index.html',site/'index.html');published=True
        shutil.copytree(stage/'frontend/dist',root/'frontend/dist',dirs_exist_ok=True)
        state.update(deployed=True,new_index_sha256=digest(site/'index.html'),product_updated_at=now)
        save(state);checks=verify(state)
        print(json.dumps({'deployed':True,'url':'https://aurius.com.au/products','backup':state['backup'],'checks':checks},indent=2),flush=True)
    except Exception:
        if published:atomic(backup/'index.html',site/'index.html')
        for name in copied:
            original=backup/'source'/name
            if original.exists():atomic(original,root/'frontend'/name)
        if photo_updated:
            with sqlite3.connect(database,timeout=15) as connection:
                result=connection.execute('UPDATE Product SET images=?,updatedAt=? WHERE id=2 AND images=? AND updatedAt=?',(state['product_before']['images'],state['product_before']['updatedAt'],after,now))
                assert result.rowcount==1,'Product rollback refused to overwrite a later edit'
        state.update(deployed=False,rolled_back=True);save(state);raise
elif mode=='verify':
    state=json.loads((workspace/'state.json').read_text());print(json.dumps(verify(state),indent=2))
else:raise ValueError('Invalid operation')
