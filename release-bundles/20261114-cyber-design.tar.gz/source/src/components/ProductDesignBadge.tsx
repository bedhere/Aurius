import { useI18n } from '../i18n/LanguageContext';

const DESIGN_MODELS = new Set(['AU-9585-BN', 'AU-9585-BRD']);
const DESIGN_BADGE = '/products/cyber-registered-design-202616120.png';

export default function ProductDesignBadge({ product, compact = false }: {
  product: { sku: string; model?: string | null };
  compact?: boolean;
}) {
  const { language } = useI18n();
  if (!DESIGN_MODELS.has(product.sku.trim().toUpperCase())) return null;
  const label = language === 'zh-CN'
    ? '澳大利亚注册外观设计，设计编号 202616120'
    : 'Australian registered design — Design No. 202616120';

  return (
    <a className={`product-design-badge${compact ? ' product-design-badge--compact' : ''}`}
      href={DESIGN_BADGE} target="_blank" rel="noreferrer" aria-label={label}>
      <img src={DESIGN_BADGE} alt={label} width="2172" height="724" loading="lazy" />
    </a>
  );
}
